while [ true ];
do node index.js
done
