---
name: Report User
about: Report Auto-Catchers made with PokéAssistant
title: ''
labels: report
assignees: ''

---

**Auto-Catcher Information**
Provide auto-catcher's ID and their PokéAssistant bot's ID. Also the Server ID and Invite (If Possible).

**Screenshots**
Add screenshots of messages sent by the Auto-Catcher. (Required)

**Additional context**
Add any other context about the problem here.
